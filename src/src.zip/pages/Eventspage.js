// src/components/home/Home.js
import React from 'react';
import FiltersSidebar from '../components/events/FiltersSidebar'; // Importing FiltersSidebar component
import Calendar from '../components/events/Calendar';

import '../assets/styles/eventspage.css'; 

const Home = () => {
  return ( <><aside className="sidebar">
    <FiltersSidebar />
  </aside>
 
<main className="calendar-container">
      <div  >
        <Calendar />
      </div>
   
    </main></>
  );
};

export default Home;
