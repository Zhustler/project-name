import React from 'react';
import RelatedEvents from '../components/news/RelatedEvents'; // Importing IntroVideo component
import AnnouncementList from '../components/news/AnnouncementList'; // Importing PopupVideo component
import '../assets/styles/news.css'; 

const NewsPage = () => {
  return (
    
    <main>
      <RelatedEvents />
      <section className="main-section" id="announcements">
        <AnnouncementList />
      </section>
    </main>
    
  );
};

export default NewsPage;
