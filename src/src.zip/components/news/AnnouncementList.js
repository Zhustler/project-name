import React, { useEffect, useState } from 'react';

const AnnouncementList = () => {
  const [announcements, setAnnouncements] = useState([]);

  useEffect(() => {
    const storedAnnouncements = JSON.parse(localStorage.getItem('announcements')) || [];

    storedAnnouncements.sort((a, b) => new Date(b.date) - new Date(a.date)); // Latest first

    setAnnouncements(storedAnnouncements);
  }, []);

  return (
    <>
      <h2>Announcements</h2>
      <div id="announcement-list" className="announcement-cards-container">
        {announcements.length === 0 ? (
          <p>No announcements available.</p>
        ) : (
          announcements.map((announcement, index) => {
            const categoryClass = announcement.category.toLowerCase().replace(/\s+/g, '-');

            return (
              <div key={index} className={`announcement-item ${categoryClass}`}>
                <div className="category">
                  <div className="category2">
                    <h3>
                      <br />
                      &nbsp;&nbsp;&nbsp;
                      <a
                        href={announcement.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ color: 'inherit' }}
                      >
                        {announcement.title}
                      </a>
                      <br />
                      <br />
                    </h3>
                  </div>
                  <p>{announcement.description}</p>
                  <p>
                    <strong>de:</strong> {announcement.category}
                  </p>
                  <div className="category3">
                    <p>
                      Télécharger le fichier:{' '}
                      <a
                        href={announcement.file}
                        target="_blank"
                        rel="noopener noreferrer"
                        download={announcement.file}
                      >
                        {announcement.file}
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </>
  );
};

export default AnnouncementList;
