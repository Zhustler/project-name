import React from 'react';
import { Link } from 'react-router-dom'; // Importing Link for navigation
import '../assets/styles/NavBar.css';




function NavBar() {
  return (
    <nav className="horizontal-nav">
      <ul>
        <li className="active">
          <Link to="/" className="nav-item">
            <img src="../photos/logoo.png" alt="logo" width="80" id="home-link" />
          </Link>
        </li>
        <li>
          <Link to="/news" className="nav-item">Actualités</Link>
        </li>
        <li>
          <Link to="/gallery" className="nav-item">Galerie</Link>
        </li>
        <li>
          <Link to="/about" className="nav-item">À propos</Link>
        </li>
        <li>
          <Link to="/shop" className="nav-item">Boutique</Link>
        </li>
        <li>
          <Link to="/contact" className="nav-item">Contact</Link>
        </li>
        <li>
          <a href="https://www.fsb.univh2c.ma/" className="nav-item">
            <img src="../photos/logolafac.png" alt="logo" width="80" />
          </a>
        </li>
      </ul>
    </nav>
  );
}

export default NavBar;
