// src/components/contact/MessagesList.js
import React, { useEffect, useState } from 'react';

const MessagesList = () => {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const storedMessages = JSON.parse(localStorage.getItem('messages')) || [];
    setMessages(storedMessages);
  }, []);

  return (
    <section>
      <h2>Messages Recus</h2>
      {messages.length === 0 ? (
        <p>No messages available.</p>
      ) : (
        <div>
          {messages.map((msg, index) => (
            <div key={index} className="message-card">
              <p><strong>Name:</strong> {msg.name}</p>
              <p><strong>Email:</strong> {msg.email}</p>
              <p><strong>Message:</strong> {msg.message}</p>
              <p><strong>Code Apogée:</strong> {msg.codeapogee}</p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};

export default MessagesList;
