// components/SectionSlider.jsx
import React from 'react';

const SectionSlider = ({ title, sectionId }) => {
  return (
    <section className="main-section">
      <h2 align="center">{title}</h2>
      <div className={sectionId === "all-items" ? "slider-container" : "category-container"}>
        <div id={`${sectionId}-cards`} className="cards-wrapper">
          {/* Cards will be inserted dynamically */}
        </div>
       <div className="slider-controls">
          <button id={`prev-${sectionId}-cards`} className="slider-button">&#10094;</button>
          <button id={`next-${sectionId}-cards`} className="slider-button">&#10095;</button>
        </div>
      </div>
    </section>
  );
}; 

export default SectionSlider;
