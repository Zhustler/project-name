// components/AllItemsSection.jsx
import React from 'react';
import SectionSlider from './SectionSlider';

const AllItemsSection = () => {
  return (
    <section className="main-section">
      <h2 style={{ textAlign: 'center' }}>Tous les Articles</h2>
      <div className="slider-container">
        <div id="all-items-cards" className="cards-wrapper">
          {/* Cards will be rendered here dynamically */}
        </div>
        <div className="slider-controls">
          <button id="prev-all-items-cards" className="slider-button">&#10094;</button>
          <button id="next-all-items-cards" className="slider-button">&#10095;</button>
        </div>
      </div>
    </section>
  );
};

export default AllItemsSection;