// src/components/home/PopupVideo.js
import React, { useState, useEffect, useRef } from 'react';

const PopupVideo = () => {
  const [showPopup, setShowPopup] = useState(false);
  const videoRef = useRef(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.onended = () => {
        setShowPopup(false); // Hide the popup after the video ends
      };
    }
  }, []);

  const handleClosePopup = () => {
    setShowPopup(false); // Manually close the popup
  };

  const handleOpenPopup = () => {
    setShowPopup(true); // Show the popup video
  };

  return (
    <div>
      {/* Button to open the popup video */}
      <button onClick={handleOpenPopup} className="open-video-btn">
        Watch Popup Video
      </button>

      {/* Popup Video */}
      {showPopup && (
        <div id="video-popup" className="popup">
          <div className="popup-content">
            <video
              ref={videoRef}
              autoPlay
              muted
              className="popup-video"
            >
              <source src="../videos/export.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <button onClick={handleClosePopup} className="close-btn">
              &times; Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PopupVideo;
