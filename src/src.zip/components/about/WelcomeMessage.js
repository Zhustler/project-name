// src/components/news/WelcomeMessage.js
import React, { useEffect } from 'react';

const WelcomeMessage = () => {
  return (
    <section className="welcome-message">
      <div className="name">
        <h1>Notre Membres bureau :</h1>
      </div>
      <div className="container swiper" id="swiper-container">
        <div className="card-wrapper">
          <ul className="card-list swiper-wrapper">
            <li className="card-item swiper-slide">
              <a href="#" className="card-link">
                <img
                  src="../photos/WhatsApp Image 2024-11-30 at 00.00.08_4484c7fc.jpg"
                  alt="card Image"
                  className="card-image"
                />
                <p className="badge">ABDELLAH RAFIK</p>
                <h2 className="card-title">
                  Chef d'organisation et étudiant en 2ᵉ année de licence en
                  développement informatique.
                </h2>
              </a>
            </li>
            {/* Add other card items similarly */}
          </ul>
          <div className="swiper-pagination"></div>
          <div className="swiper-button-prev"></div>
          <div className="swiper-button-next"></div>
        </div>
      </div>
    </section>
  );
};

export default WelcomeMessage;
