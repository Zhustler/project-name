import React, { useState, useEffect } from 'react';

const AddEventForm = () => {
    const [eventTitle, setEventTitle] = useState('');
    const [eventDate, setEventDate] = useState('');
    const [eventCategory, setEventCategory] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        // Create a new event object with the provided values
        const newEvent = { date: eventDate, title: eventTitle, category: eventCategory };

        // Retrieve existing events from localStorage or initialize with an empty array
        let events = JSON.parse(localStorage.getItem("events")) || [];

        // Add the new event to the array
        events.push(newEvent);

        // Save the updated events array back to localStorage
        localStorage.setItem("events", JSON.stringify(events));

        // Reset form fields
        setEventTitle('');
        setEventDate('');
        setEventCategory('');

        // Show success message
        alert("Event added successfully!");

        // Optionally, you can call a function to re-render events if needed
        // renderEvents(); // Uncomment if you have a function to render events
    };

    useEffect(() => {
        // You can add any logic that needs to be executed once the component mounts
    }, []);

    return (
        <section className="main-section">
            <h2>Ajouter un événement</h2>
            <form onSubmit={handleSubmit}>
                <div className="textInputWrapper">
                    <input
                        type="text"
                        className="textInput"
                        placeholder="Titre de l'événement"
                        required
                        value={eventTitle}
                        onChange={(e) => setEventTitle(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <input
                        type="date"
                        className="textInput"
                        required
                        value={eventDate}
                        onChange={(e) => setEventDate(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <input
                        type="text"
                        className="textInput"
                        placeholder="Catégorie"
                        required
                        value={eventCategory}
                        onChange={(e) => setEventCategory(e.target.value)}
                    />
                </div>
                <button type="submit">Ajouter un événement</button>
            </form>
        </section>
    );
};

export default AddEventForm;
