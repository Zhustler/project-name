import React, { useState, useEffect } from 'react';

const EventListSection = () => {
    const [events, setEvents] = useState([]);

    // Fetch events from localStorage when the component mounts
    useEffect(() => {
        const storedEvents = JSON.parse(localStorage.getItem("events")) || [];
        setEvents(storedEvents);
    }, []);

    // Delete event by index
    const deleteEvent = (index) => {
        const updatedEvents = events.filter((_, i) => i !== index);
        setEvents(updatedEvents); // This will trigger a re-render
        localStorage.setItem("events", JSON.stringify(updatedEvents)); // Update localStorage
    };

    // Event card rendering
    const renderEventCards = () => {
        if (events.length === 0) {
            return <p>No events available.</p>;
        }

        return events.map((event, index) => {
            const categoryClass = event.category.toLowerCase().replace(/\s+/g, '-');
            return (
                <div key={index} className={`event-item ${categoryClass}`}>
                    <h3>{event.title}</h3>
                    <p><strong>Date:</strong> {event.date}</p>
                    <p><strong>Category:</strong> {event.category}</p>
                    <button onClick={() => deleteEvent(index)}>Delete</button>
                </div>
            );
        });
    };

    return (
        <section className="main-section">
            <h2>Liste des événements</h2>
            <div className="event-cards-container">
                {renderEventCards()}
            </div>
            <div className="slider-buttons">
                <button className="prev" id="prev-event-slide">
                    &#10094;
                </button>
                <button className="next" id="next-event-slide">
                    &#10095;
                </button>
            </div>
        </section>
    );
};

export default EventListSection;
