import React from 'react';

const ContactFormSubmissionsSection = () => {
    return (
        <section className="main-section">
            <h2>Soumissions du formulaire de contact</h2>
            <div id="message-list" className="message-cards-container">
                {/* Messages will be dynamically rendered here */}
            </div>
            <div className="slider-buttons">
                <button className="prev" id="prev-message-slide">
                    &#10094;
                </button>
                <button className="next" id="next-message-slide">
                    &#10095;
                </button>
            </div>
        </section>
    );
};

export default ContactFormSubmissionsSection;
