import React, { useState } from 'react';

const AddAnnouncementForm = () => {
    const [announcementTitle, setAnnouncementTitle] = useState('');
    const [file, setFile] = useState(null);
    const [description, setDescription] = useState('');
    const [announcementLink, setAnnouncementLink] = useState('');
    const [announcementCategory, setAnnouncementCategory] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        // Check if a file is uploaded, otherwise use a default message
        const announcementFile = file ? file.name : "No file uploaded";

        // Create a new announcement object with the provided values
        const newAnnouncement = {
            title: announcementTitle,
            file: announcementFile,
            description: description,
            link: announcementLink,
            category: announcementCategory, // Add category to the new announcement
        };

        // Retrieve existing announcements from localStorage or initialize with an empty array
        let announcements = JSON.parse(localStorage.getItem("announcements")) || [];

        // Add the new announcement to the array
        announcements.push(newAnnouncement);

        // Save the updated announcements array back to localStorage
        localStorage.setItem("announcements", JSON.stringify(announcements));

        // Reset form fields
        setAnnouncementTitle('');
        setFile(null);
        setDescription('');
        setAnnouncementLink('');
        setAnnouncementCategory('');

        // Show success message (could replace with actual notification UI)
        alert("Announcement added successfully!");

        // Call function to re-render or handle the announcements
        // Example: renderAnnouncements(); if it's part of your state management
    };

    return (
        <section className="main-section">
            <h2>Ajouter une annonce</h2>
            <form onSubmit={handleSubmit}>
                <div className="textInputWrapper">
                    <input
                        type="text"
                        className="textInput"
                        placeholder="Titre de l'annonce"
                        required
                        value={announcementTitle}
                        onChange={(e) => setAnnouncementTitle(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <input
                        type="file"
                        className="textInput"
                        onChange={(e) => setFile(e.target.files[0])}
                    />
                </div>
                <div className="textInputWrapper">
                    <input
                        type="text"
                        className="textInput"
                        placeholder="Description"
                        required
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <input
                        type="url"
                        className="textInput"
                        placeholder="Lien"
                        required
                        value={announcementLink}
                        onChange={(e) => setAnnouncementLink(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <select
                        className="textInput"
                        required
                        value={announcementCategory}
                        onChange={(e) => setAnnouncementCategory(e.target.value)}
                    >
                        <option value="" disabled selected>
                            Catégorie
                        </option>
                        <option value="faculty">Faculté</option>
                        <option value="Club">Club</option>
                    </select>
                </div>
                <button type="submit">Ajouter une annonce</button>
            </form>
        </section>
    );
};

export default AddAnnouncementForm;
