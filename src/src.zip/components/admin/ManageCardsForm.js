import React, { useState } from 'react';

const ManageCardsForm = () => {
    const [cardTitle, setCardTitle] = useState('');
    const [cardNewPrice, setCardNewPrice] = useState('');
    const [cardStock, setCardStock] = useState('');
    const [cardCategory, setCardCategory] = useState('tickets');
    const [cardLink, setCardLink] = useState('');
    const [cardImage, setCardImage] = useState(null);

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle form submission logic here (e.g., saving the card)
        console.log({
            cardTitle,
            cardNewPrice,
            cardStock,
            cardCategory,
            cardLink,
            cardImage,
        });
    };

    return (
        <div className="main-section">
            <h2>Gérer les articles</h2>
            <form id="cards-form" onSubmit={handleSubmit}>
                <div className="textInputWrapper">
                    <input
                        type="text"
                        id="card-title"
                        placeholder="Titre de la carte"
                        className="textInput"
                        required
                        value={cardTitle}
                        onChange={(e) => setCardTitle(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <input
                        type="number"
                        id="card-new-price"
                        placeholder="prix"
                        className="textInput"
                        required
                        value={cardNewPrice}
                        onChange={(e) => setCardNewPrice(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <input
                        type="number"
                        id="card-stock"
                        placeholder="Stock"
                        className="textInput"
                        required
                        value={cardStock}
                        onChange={(e) => setCardStock(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <select
                        id="card-category"
                        className="textInput"
                        required
                        value={cardCategory}
                        onChange={(e) => setCardCategory(e.target.value)}
                    >
                        <option value="tickets">Billets</option>
                        <option value="merch">Merch</option>
                        <option value="other">Autre</option>
                    </select>
                </div>
                <div className="textInputWrapper">
                    <input
                        type="url"
                        id="card-link"
                        placeholder="Lien de dépôt"
                        className="textInput"
                        required
                        value={cardLink}
                        onChange={(e) => setCardLink(e.target.value)}
                    />
                </div>
                <div className="textInputWrapper">
                    <input
                        type="file"
                        id="card-image"
                        className="textInput"
                        accept="image/*"
                        required
                        onChange={(e) => setCardImage(e.target.files[0])}
                    />
                </div>
                <button type="submit">Ajouter une carte</button>
            </form>
        </div>
    );
};

export default ManageCardsForm;
